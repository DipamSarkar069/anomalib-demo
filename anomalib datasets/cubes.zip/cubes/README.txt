DOBOT Cubes Dataset

Source: https://github.com/openvinotoolkit/anomalib/releases/download/dobot/cubes.zip

License type: Creative Commons 4.0

Description:
Dataset contains RGB images of three industrial products
    - normal : Contains 116 images of 640x480 pixels.
    - abnormal : Contains 72 images of 640x480 pixels.
